#include "net.h"
#include "ip.h"
#include "ethernet.h"
#include "arp.h"
#include "icmp.h"
uint16_t global_id = 0;
#define IP_MTU 1500
/**
 * @brief 处理一个收到的数据包
 * 
 * @param buf 要处理的数据包
 * @param src_mac 源mac地址
 */
void ip_in(buf_t *buf, uint8_t *src_mac)
{
    // TO-DO
    if(buf->len < sizeof(ip_hdr_t)){
        return;
    }
    ip_hdr_t* data = (ip_hdr_t*)buf->data;
    if(data->version == IP_VERSION_4 && swap16(data->total_len16) <= buf->len){
        uint16_t checksum = data->hdr_checksum16;
        data->hdr_checksum16 = 0;
        uint16_t x = checksum16((uint16_t*)data,data->hdr_len * IP_HDR_LEN_PER_BYTE);
        if(memcmp(net_if_ip,data->dst_ip,NET_IP_LEN) || (checksum != x)){
            return;
        }
        data->hdr_checksum16 = checksum;
        if(swap16(data->total_len16) < buf->len){
            buf_remove_padding(buf,buf->len - swap16(data->total_len16));
        }
        buf_remove_header(buf,sizeof(ip_hdr_t));
        if(net_in(buf,data->protocol,data->src_ip) == -1){
            buf_add_header(buf,sizeof(ip_hdr_t));
            icmp_unreachable(buf,data->src_ip,ICMP_CODE_PROTOCOL_UNREACH);
        }
    }
}

/**
 * @brief 处理一个要发送的ip分片
 * 
 * @param buf 要发送的分片
 * @param ip 目标ip地址
 * @param protocol 上层协议
 * @param id 数据包id
 * @param offset 分片offset，必须被8整除
 * @param mf 分片mf标志，是否有下一个分片
 */
void ip_fragment_out(buf_t *buf, uint8_t *ip, net_protocol_t protocol, int id, uint16_t offset, int mf)
{
    // TO-DO
    buf_add_header(buf,sizeof(ip_hdr_t));
    ip_hdr_t* ip_hdr = (ip_hdr_t*)buf->data;
    ip_hdr->version = IP_VERSION_4;
    ip_hdr->hdr_len = sizeof(ip_hdr_t)/IP_HDR_LEN_PER_BYTE;
    ip_hdr->tos = 0;
    ip_hdr->total_len16 = swap16(buf->len);
    ip_hdr->ttl = IP_DEFALUT_TTL;
    ip_hdr->id16 = swap16(id);
    ip_hdr->flags_fragment16 = swap16(mf << 13 | offset);
    ip_hdr->protocol = protocol;
    ip_hdr->hdr_checksum16 = 0;
    memcpy(ip_hdr->dst_ip,ip,NET_IP_LEN);
    memcpy(ip_hdr->src_ip,net_if_ip,NET_IP_LEN);
    ip_hdr->hdr_checksum16 = (checksum16((uint16_t*)ip_hdr,ip_hdr->hdr_len * IP_HDR_LEN_PER_BYTE));
    arp_out(buf,ip);
}

/**
 * @brief 处理一个要发送的ip数据包
 * 
 * @param buf 要处理的包
 * @param ip 目标ip地址
 * @param protocol 上层协议
 */
void ip_out(buf_t *buf, uint8_t *ip, net_protocol_t protocol)
{
    // TO-DO
    int size = IP_MTU - sizeof(ip_hdr_t);
    if(buf->len > size){
        int n = buf->len / size;
        int flag = (buf->len % size == 0);
        buf_t b1,b2;
        for(int i = 0;i < n;i++){
            buf_init(&b1,size);
            memcpy(b1.data,buf->data + i * size,size);
            if(flag && i == n-1){
                ip_fragment_out(&b1,ip,protocol,global_id,i * size / IP_HDR_OFFSET_PER_BYTE,0);
            }
            else{
                ip_fragment_out(&b1,ip,protocol,global_id,i * size / IP_HDR_OFFSET_PER_BYTE,1);
            }
        }
        if(!flag){
            buf_init(&b2,buf->len - n * size);
            memcpy(b2.data,buf->data + n * size,buf->len - n * size);
            ip_fragment_out(&b2,ip,protocol,global_id,n * size / IP_HDR_OFFSET_PER_BYTE,0);
        }
    }
    else{
        ip_fragment_out(buf,ip,protocol,global_id,0,0);
    }
    global_id++;

}

/**
 * @brief 初始化ip协议
 * 
 */
void ip_init()
{
    net_add_protocol(NET_PROTOCOL_IP, ip_in);
}