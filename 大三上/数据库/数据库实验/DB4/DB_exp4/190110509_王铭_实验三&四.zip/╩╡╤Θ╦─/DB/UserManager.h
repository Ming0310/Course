﻿#pragma once
#include <iostream>
#include <list>
#include <string>
#include "User.h"
using namespace std;
class UserManager
{
public:
    int size = 0;
    list<User*> userList;
    list<orders*>orderList;
    list<orders*>getOrderList();
    UserManager();
    ~UserManager();
    /*
        添加一个用户，flag为false表示是从数据库中加载，否则在数据库中新增一条用户信息
        添加成功返回1
    */
    int addUser(User* user, bool flag = true);
    int deleteUser(User* user); //
    User* query(string name); // 查询数据库中用户是否已经存在，若存在则返回一个User类的指针，否则返回NULL
    void initial(); // 将数据库中已有的用户信息导入
    void save(User* user);
    void printUser();
    int addOrders(orders* order,bool flag = true);// 向manager的orderList和数据库添加一个订单
    int deleteOrders(QString order_id); // 从manager的orderList和数据库里删除
    int queryOrder(QString order_id); // 从数据库里查询订单是否存在，若存在返回1，否则返回0
};
