﻿#include "orderinfo.h"
#include "ui_orderinfo.h"
#include "global.h"
#include <QSqlQuery>
#include <QDebug>
OrderInfo::OrderInfo(QString id,QWidget *parent) :
    QWidget(parent),
    ui(new Ui::OrderInfo)
{
    ui->setupUi(this);
    setWindowTitle("OrderInfo");
    QSqlQuery q(db);
    q.prepare("select store_name,dish_name,number,CName,dish_price from canteen,dish,orders_dish,store where order_id = :id "
              "and orders_dish.dish_id = dish.dish_id "
              "and dish.store_id = store.store_id "
              "and store.canteen_id = canteen.canteen_id");
    q.bindValue(":id",id);
    q.exec();
    QString title = "食堂名称\t商户名称\t菜品名称\t菜品价格\t菜品数量\t";
    QListWidgetItem* it = new QListWidgetItem(title);
    ui->listWidget->addItem(it);
    it->setSizeHint(QSize(500,30));
    while(q.next()){
        QString s = q.value("CName").toString()+"\t"+q.value("store_name").toString() + "\t";
        s += q.value("dish_name").toString() + "\t" + q.value("dish_price").toString() + "\t"+q.value("number").toString();
        QListWidgetItem* it = new QListWidgetItem(s);
        ui->listWidget->addItem(it);
        it->setSizeHint(QSize(50,30));
    }
}

OrderInfo::~OrderInfo()
{
    delete ui;
}
