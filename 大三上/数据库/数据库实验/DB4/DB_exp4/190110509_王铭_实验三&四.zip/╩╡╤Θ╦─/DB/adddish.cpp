﻿#include "adddish.h"
#include "ui_adddish.h"
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>
#include "global.h"
#include <QMessageBox>
AddDish::AddDish(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddDish)
{
    ui->setupUi(this);
    //显示食堂
    QSqlQuery q(db);
    q.exec("select CName from canteen");
    while(q.next()){
        ui->comboBox->addItem(q.value("CName").toString());
    }
    //添加菜品
    connect(ui->pushButton_3,&QPushButton::clicked,[=](){
        int x = add(ui->comboBox->currentText(),ui->lineEdit->text(),ui->lineEdit_2->text(),ui->lineEdit_3->text());
        if(x == 1)
        {
            this->close();
            emit success();
        }
    });
    connect(ui->pushButton_4,&QPushButton::clicked,[=](){
        this->close();
    });
}

AddDish::~AddDish()
{
    delete ui;
}
int AddDish::add(QString CName,QString store_name, QString dish_name, QString dish_price){
    QSqlQuery q(db);
        // 1. 获取当前最大的菜品id
    int id = 0;
    q.exec("select * from dish");
    while(q.next()){
        if(q.value("dish_id").toInt() > id){
            id = q.value("dish_id").toInt();
        }
    }
    // 2.获取商户的id
    QSqlQuery q2(db);
    q2.prepare("select store_id from store,canteen where store_name = :store_name AND "
               "CName = :CName AND canteen.canteen_id = store.canteen_id");
    q2.bindValue(":store_name",store_name);
    q2.bindValue(":CName",CName);
    q2.exec();
    if(!q2.next()){
        QMessageBox::information(this,"商户查询错误","并未找到该商户！",QMessageBox::Yes);
        return 0;
    }
    else{
        // 3.插入
        QSqlQuery query(db);
        query.prepare("Insert into dish(dish_name,dish_id,store_id,dish_price)Values(:dish_name,:id,:cid,:price)");
        query.bindValue(":dish_name",dish_name);
        query.bindValue(":id",QString::number(id+1));
        query.bindValue(":cid",q2.value("store_id").toString());
        query.bindValue(":price",dish_price.toFloat());
        query.exec();
    }
            return 1;
}
