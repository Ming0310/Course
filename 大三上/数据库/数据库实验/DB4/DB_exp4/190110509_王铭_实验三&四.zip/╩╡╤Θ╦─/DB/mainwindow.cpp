﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "login.h"
#include <QDebug>
#include <QTableWidgetItem>
#include <QString>
#include <QAction>
#include "orderdialog.h"
#include <QMessageBox>
#include "global.h"
#include "statusdialog.h"
#include <QSqlQuery>
#include "userinfodialog.h"
#include <QPoint>
#include <QSqlError>
#include "orderinfo.h"
MainWindow::MainWindow(User* current_user,QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("食堂在线点单");
    this->current_user = current_user;
    QString s = QString("尊敬的用户，您目前登录的账户为:").append(QString::fromStdString(current_user->getUserName()));
    ui->userLabel->setText(s);
    void(QListWidget::* c)(QListWidgetItem*) = &QListWidget::itemClicked;
    // 删除订单 查看详情
    connect(ui->listWidget,c,[=](QListWidgetItem* item){
        QMenu* menu = new QMenu(ui->listWidget);
        QAction* action1 = new QAction("查看详情");
        QAction* action2 = new QAction("删除订单");
        menu->addAction(action1);
        menu->addAction(action2);
        QString text = item->text();
        if(text != "订单号\t金额\t支付状态\t时间"){
            QAction* act = menu->exec(QCursor().pos());
            if(act == action2){
                QStringList list = text.split("\t");
                QMessageBox::StandardButton result = QMessageBox::information(ui->listWidget, "提示窗口", "确认要删除订单？",QMessageBox::Yes|QMessageBox::No);
                if(result == QMessageBox::Yes){
                    // 用户删除
                    if(current_user->deleteFromOrderList(list[0].toStdString())){
                        qDebug() << "删除成功";
                    }
                    else{
                        qDebug() << "删除失败1";
                    }
                    //数据库要删除
                    if(manager.deleteOrders(list[0])){
                        qDebug() << "删除成功";
                    }
                    else{
                        qDebug() << "删除失败2";
                    }
                    printOrder();
                }
            }
            else if(act == action1){
                   // 查看详情
                   OrderInfo* o = new OrderInfo(text.split("\t")[0]);
                   o->show();
            }
        }

    });
    // 点击查看的是我的订单信息
    connect(ui->order_btn,&QPushButton::clicked,[=](){
        // 打印到listwiget上订单信息
        printOrder();

    });
    connect(ui->btn2,&QPushButton::clicked,this,&MainWindow::addOrder);
    //点击的是添加一个订单
    connect(ui->addMenu,&QAction::triggered,this,&MainWindow::addOrder);
    // 退出
    connect(ui->quitBtn,&QAction::triggered,[=](){
       this->close();
       emit reshow();
    });

    //查询历史订单
    connect(ui->action2,&QAction::triggered,[=](){
        QSqlQuery q(db);
        q.prepare("select * from orders where user_id = :id");
        q.bindValue(":id",QString::fromStdString(current_user->getUserId()));
        q.exec();
        ui->listWidget_2->clear();
        QListWidgetItem* item = new QListWidgetItem("订单号\t金额\t支付状态\t时间");
        item->setSelected(false);
        ui->listWidget_2->addItem(item);
        while(q.next()){
            QString text = "";
            text += q.value("order_id").toString();
            text = text + "\t" + q.value("total").toString()+ "\t";
            if(q.value("status_id").toInt() == 0){
                text = text + "未支付" + "\t";
            }
            else if(q.value("status_id").toInt() == 1){
                text = text + "已支付" + "\t";
            }
            else{
                text = text + "已完成" + "\t";
            }
            QString temp = q.value("order_time").toString();
            QStringList l = temp.split("T");
            temp = l[0]+" "+l[1].split(".")[0];
            text = text + temp;
            ui->listWidget_2->addItem(text);
        }
           ui->stackedWidget->setCurrentIndex(2);
    });
    //查看食堂排名
    connect(ui->canteenBtn,&QPushButton::clicked,[=](){
        ui->listWidget_2->clear();
        QSqlQuery q(db);
        q.prepare("select * from profit_rank");
        QListWidgetItem* item = new QListWidgetItem("食堂名称\t\t食堂总销售额");
        item->setSizeHint(QSize(30,30));
        ui->listWidget_2->addItem(item);
        q.exec();
        while(q.next()){
            QListWidgetItem* i = new QListWidgetItem(q.value("canteenName").toString()+"\t\t"+q.value("total_profit").toString()+"元",ui->listWidget_2);
            i->setSizeHint(QSize(20,20));
        }
        ui->stackedWidget->setCurrentIndex(2);
    });
    // 完善信息
    connect(ui->action1,&QAction::triggered,[=](){
        // 输入学号/教师号
        // 电话号码
        // 配送地址
        UserInfoDialog* d = new UserInfoDialog(current_user);
        d->exec();
    });
    // 菜品TOP3
    connect(ui->pushButton,&QPushButton::clicked,[=](){
       QSqlQuery q(db);
       bool flag = q.exec("select dish.dish_price as price,store.store_name as SName,dish.dish_name as name,SUM(orders_dish.number) as totalP,canteen.CName C from dish,store,canteen,orders_dish where orders_dish.dish_id = dish.dish_id and"
                 " store.store_id = dish.store_id and store.canteen_id = canteen.canteen_id"
                 " group by orders_dish.dish_id order by SUM(orders_dish.number) DESC");
       if(!flag) qDebug() << q.lastError();
       ui->listWidget_2->clear();
       QListWidgetItem* it = new QListWidgetItem("食堂名称\t\t商户名称\t\t菜品名称");
       ui->listWidget_2->addItem(it);
       it->setSizeHint(QSize(20,30));
       for(int i = 0;i < 3;i++){
           if(q.next()){
               // 用listwidget2就行
               QString s = q.value("C").toString()+"\t\t"+q.value("SName").toString()+"\t\t"+q.value("name").toString();
               QListWidgetItem* item = new QListWidgetItem(s);
               ui->listWidget_2->addItem(item);
               item->setSizeHint(QSize(30,50));
           }
       }
       ui->stackedWidget->setCurrentIndex(2);

    });
}

void MainWindow::addOrder(){
    OrderDialog* o = new OrderDialog(current_user);
    o->show();
}

MainWindow::~MainWindow()
{
    delete ui;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::printOrder(){
    // 打印到listwiget上订单信息
    QListWidgetItem* item = new QListWidgetItem("订单号\t金额\t支付状态\t时间");
    item->setSelected(false);
    item->setSizeHint(QSize(10,50));
    item->setFlags(item->flags() & ~Qt::ItemIsEnabled & ~Qt::ItemIsSelectable);
    ui->listWidget->clear();
    ui->listWidget->addItem(item);
    list<orders*> list;
    list = current_user->getOrderList();
    for(orders* order:list){
        QString id = QString::fromStdString(order->getOrder_id());
        QString total = QString("%1").arg(order->getTotal());
        QDateTime time = order->getOrder_time();
        QString status;
        if(order->getStatus_id() == 0) status = "未支付";
        else if(order->getStatus_id() == 1) status = "已支付";
        else status = "已完成";
        QString text = id+"\t"+total+"\t"+status+"\t"+time.toString("yyyy-MM-dd hh:mm:ss");
        QListWidgetItem* item = new QListWidgetItem(text);
        item->setSizeHint(QSize(30,50));
        ui->listWidget->addItem(item);
    }
   ui->stackedWidget->setCurrentIndex(0);
}
