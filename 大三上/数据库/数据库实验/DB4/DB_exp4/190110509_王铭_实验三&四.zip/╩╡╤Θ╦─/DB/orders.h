﻿#ifndef ORDERS_H
#define ORDERS_H
#include <iostream>
#include <QDateTime>
using namespace std;

class orders
{
    /*
        订单的基本类
    */
private:
    string order_id; //订单号
    string user_id; //用户编号
    int status_id; // 支付编号
    float total; // 订单金额
    string order_addr; // 订单送达地址
    QDateTime order_time; // 订单产生时间
public:
    orders();
    ~orders();
    orders(string order_id,string user_id,int status_id,float total,string order_addr,QDateTime order_time);
    string getOrder_id();
    string getUser_id();
    int getStatus_id();
    float getTotal();
    string getOrder_addr();
    void setOrder_id(string order_id);
    void setUser_id(string user_id);
    void setStatus_id(int status);
    void setTotal(float total);
    void setOrder_addr(string order_addr);
    void setOrder_time(QDateTime time);
    QDateTime getOrder_time();
};

#endif // ORDERS_H
