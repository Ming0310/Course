﻿#ifndef MENUDIALOG_H
#define MENUDIALOG_H

#include <QDialog>
#include "User.h"
#include "orders.h"
namespace Ui {
class MenuDialog;
}

class MenuDialog : public QDialog
{
    Q_OBJECT

public:
    /*
        添加菜品的窗口，传入的n为当前的食堂名称，s为所选的商户名
    */
    explicit MenuDialog(QString n,QString s,User* current_user,QWidget *parent = nullptr);
    ~MenuDialog();
    string getDishId(string canteen_name,string dish_name); // 通过食堂和菜品的名称获取菜品id
    float getDishPrice(string dish_id); // 通过菜品id获取菜品价格
    int updateOrder(string order_id,float price);
    orders* order;

private:
    Ui::MenuDialog *ui;
};

#endif // MENUDIALOG_H
