﻿#ifndef ROOTMAINWINDOW_H
#define ROOTMAINWINDOW_H

#include <QMainWindow>
#include <QListWidgetItem>
namespace Ui {
class RootMainWindow;
}

class RootMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit RootMainWindow(QWidget *parent = nullptr);
    ~RootMainWindow();
    void initial();
    void loadCanteen();
    void loadDish(QString t);
    void printOrder();
    void deleteStore(QListWidgetItem* item);
    int lastIndex;
signals:
    void reshow();
private:
    Ui::RootMainWindow *ui;
};

#endif // ROOTMAINWINDOW_H
