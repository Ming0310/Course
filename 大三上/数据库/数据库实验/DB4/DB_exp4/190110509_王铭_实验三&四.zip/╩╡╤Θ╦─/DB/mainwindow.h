﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <list>
#include <QList>
#include <QMainWindow>
#include "User.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    User* current_user;
    MainWindow(QWidget *parent = nullptr);
    /*
        传入参数row为用户的数量，userList为所有用户列表。
        MainWindow窗口提供查询订单 和 用户信息，其中用户信息只有root管理员可查看（待实现）
    */
    MainWindow(User* user, QWidget *parent = nullptr);
    void addOrder(); // 添加一个订单 即调用OrderDialog
    void printOrder();
    ~MainWindow();
signals:
    void reshow();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
