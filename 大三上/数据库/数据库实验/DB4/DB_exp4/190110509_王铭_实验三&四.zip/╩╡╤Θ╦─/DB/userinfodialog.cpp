﻿#include "userinfodialog.h"
#include "ui_userinfodialog.h"
#include <QSqlQuery>
#include "global.h"
#include <QMessageBox>
#include <QDebug>
#include <QSqlError>
UserInfoDialog::UserInfoDialog(User* user,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserInfoDialog)
{
    ui->setupUi(this);
    ui->line1->setText(QString::fromStdString(user->getStudentId()));
    ui->line2->setText(QString::fromStdString(user->getTel()));
    ui->line3->setText(QString::fromStdString(user->getAddr()));
    connect(ui->pushButton,&QPushButton::clicked,[=](){
        QString sid = ui->line1->text();
        QSqlQuery q1(db);
        QSqlQuery q2(db);
        q1.prepare("select * from student where student_id = :id");
        q1.bindValue(":id",sid);
        q1.exec();
        q2.prepare("select * from teacher where teacher_id = :id");
        q2.bindValue(":id",sid);
        q2.exec();
        if(!q1.next() && !q2.next()){
            QMessageBox::information(this,"error","输入学号/教师号错误",QMessageBox::Yes);
        }
        else{
            user->setTel(ui->line2->text().toStdString());
            user->setAddr(ui->line3->text().toStdString());
            user->setStudentId(ui->line1->text().toStdString());
            QSqlQuery q(db);
            q.prepare("update users set telephone = :tel,student_id = :sid where user_id = :uid");
            q.bindValue(":uid",QString::fromStdString(user->getUserId()));
            q.bindValue(":tel",QString::fromStdString(user->getTel()));
            q.bindValue(":sid",QString::fromStdString(user->getStudentId()));
            q.exec();
        }
    });

    connect(ui->pushButton,&QPushButton::clicked,[=](){
       this->close();
    });
}

UserInfoDialog::~UserInfoDialog()
{
    delete ui;
}
