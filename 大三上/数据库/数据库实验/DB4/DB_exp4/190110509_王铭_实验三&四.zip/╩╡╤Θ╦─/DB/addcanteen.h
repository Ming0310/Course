﻿#ifndef ADDCANTEEN_H
#define ADDCANTEEN_H

#include <QWidget>

namespace Ui {
class AddCanteen;
}

class AddCanteen : public QWidget
{
    Q_OBJECT

public:
    explicit AddCanteen(QWidget *parent = nullptr);
    ~AddCanteen();
    int Add(QString CName,QString Floor,QString Address);
signals:
    void addSuccess(QString name);
private:
    Ui::AddCanteen *ui;
};

#endif // ADDCANTEEN_H
