﻿#include "rootmainwindow.h"
#include "ui_rootmainwindow.h"
#include "global.h"
#include "QDebug"
#include <QTableWidgetItem>
#include <QSqlError>
#include <QSqlQuery>
#include "addcanteen.h"
#include <QFont>
#include <QComboBox>
#include <QMessageBox>
#include <QAction>
#include "statusdialog.h"
#include "adddish.h"
#include "addstore.h"
RootMainWindow::RootMainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::RootMainWindow)
{
    /*
        商户信息在listWidget(0) 菜品在listWidget_2(1)
        用户信息TableWidget 订单信息在ListWidget_3

    */
    ui->setupUi(this);
    setWindowTitle("管理员界面");
    initial();
    // 打印所有用户信息
    connect(ui->actionc,&QAction::triggered,[=](){
        ui->tableWidget->clear();
        //打印到TableWidget上的用户信息
        ui->tableWidget->setColumnCount(5);
        ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "用户名" << "密码" << "用户类别" << "电话号码" <<"学生教师号");
        int k = 0;
        ui->tableWidget->setRowCount(manager.userList.size());
        for(User* user : manager.userList){
            QStringList list;
            QString name = QString::fromStdString(user->getUserName());
            QString password = QString::fromStdString(user->getPassword());
            QString tel = QString::fromStdString(user->getTel());
            QString temp = QString::fromStdString(user->getType());
            QString type;
            if(temp == "1")type = "教师";
            else if(temp == "2") type = "工作人员";
            else type = "学生";
            QString student_id = QString::fromStdString(user->getStudentId());
            list << name << password << type << tel << student_id;
            for(int i = 0;i < 5;i++){
                QTableWidgetItem* item = new QTableWidgetItem(list[i]);
                item->setFlags(item->flags() & (~Qt::ItemIsEditable));
                ui->tableWidget->setItem(k,i,item);
            }
            k++;
        }
        ui->stackedWidget->setCurrentIndex(2);
    });
    // 退出
    connect(ui->actiont,&QAction::triggered,[=](){
        this->close();
        emit reshow();
    });
    // 打印食堂商户
    void(QComboBox::*changed)(int) =  &QComboBox::currentIndexChanged;
    void(QListWidget::* c2)(QListWidgetItem*)=&QListWidget::itemDoubleClicked;
    connect(ui->comboBox,changed,[=](){
        loadCanteen();
    });
    // 查看商户/删除
    void(QListWidget::* c)(QListWidgetItem*) = &QListWidget::itemClicked;
    connect(ui->listWidget,c,[=](QListWidgetItem* item){
        QMenu* menu = new QMenu(ui->listWidget);
        QAction* action1 = new QAction("查看菜品");
        QAction* action2 = new QAction("删除商户");
        menu->addAction(action1);
        menu->addAction(action2);
        QAction* re = menu->exec(QCursor().pos());
         if(re == action1){ // 查看详情
             loadDish(item->text());
         }
         else if(re == action2){
             // 直接删除商户
             QMessageBox::StandardButton result = QMessageBox::information(ui->listWidget,"确认提示","确定要删除该商户？",QMessageBox::Ok | QMessageBox::Cancel);
             if(result == QMessageBox::Ok)
                deleteStore(item);
         }
    });

    // 添加食堂
    connect(ui->action1,&QAction::triggered,[=](){
        AddCanteen* a = new AddCanteen();
        a->show();
        void(AddCanteen::* x)(QString) = &AddCanteen::addSuccess;
        connect(a,x,[=](QString name){
            ui->comboBox->addItem(name);
        });
    });
    //增加商户
    connect(ui->action1_2,&QAction::triggered,[=](){
        AddStore* a = new AddStore();
        connect(a,&AddStore::success,[=](){
           loadCanteen();
        });
        a->show();
    });
    // 增加菜品
    connect(ui->action1_5,&QAction::triggered,[=](){
        AddDish* a = new AddDish();
        connect(a,&AddDish::success,[=](){
           loadCanteen();
        });
        a->show();
    });
    //打印订单信息
    connect(ui->action1_3,&QAction::triggered,[=](){
       printOrder();
    });

    // 改变订单状态
    connect(ui->listWidget_3,c2,[=](QListWidgetItem* item){
           QString order_id = item->text().split("\t")[0];
           QString s = item->text().split("\t")[2];
           int status_id;
           if(s == "未支付") status_id = 0;
           else if(s == "已支付") status_id = 1;
           else status_id = 2;
           StatusDialog* d = new StatusDialog(this);
           d->exec();
           int status = d->getStatusId();
           if(status >= 0 && status != status_id){
               // 更新order_list 和 数据库
                qDebug() << order_id <<status;
                for(orders * order : manager.orderList){
                    if(order->getOrder_id() == order_id.toStdString()){
                        order->setStatus_id(status);
                        break;
                    }
                }
                QSqlQuery q(db);
                q.prepare("update orders set status_id = :id where order_id = :order_id");
                q.bindValue(":id",status);
                q.bindValue(":order_id",order_id);
                q.exec();
                printOrder();
           }
    });
}

RootMainWindow::~RootMainWindow()
{
    delete ui;
}
void RootMainWindow::initial(){
    QSqlQuery query(db);
    query.exec("select * from canteen");
    while(query.next()){
        ui->comboBox->addItem(query.value("CName").toString());
    }

    loadCanteen();
}

void RootMainWindow::loadCanteen(){
    ui->listWidget->clear();
    qDebug() << ui->comboBox->currentText();
    QSqlQuery query(db);
    query.prepare("select store_name from store,canteen where store.canteen_id = canteen.canteen_id AND CName = :CName");
    query.bindValue(":CName",ui->comboBox->currentText());
    if(query.exec()){
        while(query.next()){
            QListWidgetItem* item = new QListWidgetItem(query.value("store_name").toString(),ui->listWidget);
            item->setSizeHint(QSize(50,50));
        }
    }
    else{
        qDebug() << query.lastError();
    }
    ui->stackedWidget->setCurrentIndex(0);
}

void RootMainWindow::loadDish(QString t){
    ui->listWidget_2->clear();
    QSqlQuery query(db); // 查询当前所选的食堂的商户提供的菜品，打印到ListWidget上
    query.prepare("select dish_name,dish_price from store,dish,canteen where store.store_id = dish.store_id "
                  "AND store.canteen_id = canteen.canteen_id AND CName = :CName AND store_name = :SName");
    query.bindValue(":CName",ui->comboBox->currentText());
    query.bindValue(":SName",t);
    if(query.exec()){
        while(query.next()){
            QListWidgetItem* item = new QListWidgetItem(query.value("dish_name").toString() + "\t价格：" + query.value("dish_price").toString()+"元",ui->listWidget_2);
            item->setSizeHint(QSize(50,50));
        }
    }
    else{
        qDebug() << query.lastError();
    }
    ui->stackedWidget->setCurrentIndex(1);
}
void RootMainWindow::printOrder(){
    // 打印到listwiget上订单信息
    QListWidgetItem* item = new QListWidgetItem("订单号\t金额\t支付状态\t时间");
    item->setSelected(false);
    item->setSizeHint(QSize(10,50));
    item->setFlags(item->flags() & ~Qt::ItemIsEnabled & ~Qt::ItemIsSelectable);
    ui->listWidget_3->clear();
    ui->listWidget_3->addItem(item);
    list<orders*> list;
    list = manager.getOrderList();
    for(orders* order:list){
        QString id = QString::fromStdString(order->getOrder_id());
        QString total = QString("%1").arg(order->getTotal());
        QDateTime time = order->getOrder_time();
        QString status;
        if(order->getStatus_id() == 0) status = "未支付";
        else if(order->getStatus_id() == 1) status = "已支付";
        else status = "已完成";
        QString text = id+"\t"+total+"\t"+status+"\t"+time.toString("yyyy-MM-dd hh:mm:ss");
        QListWidgetItem* item = new QListWidgetItem(text);
        item->setSizeHint(QSize(30,50));
        ui->listWidget_3->addItem(item);

    }
   ui->stackedWidget->setCurrentIndex(3);
}
void RootMainWindow::deleteStore(QListWidgetItem* item){
    QSqlQuery query(db); // 查询当前所选的食堂的商户提供的菜品，打印到ListWidget上
    query.prepare("select store_id from store,canteen where store.store_name = :SName AND"
                  " canteen.CName = :CName AND store.canteen_id = canteen.canteen_id");
    query.bindValue(":CName",ui->comboBox->currentText());
    query.bindValue(":SName",item->text());
    query.exec();
    query.next();
    QString store_id = query.value("store_id").toString();
    QSqlQuery q(db);
    q.prepare("delete from store where store_id = :store_id");
    q.bindValue(":store_id",store_id);
    q.exec();
    loadCanteen();
}
