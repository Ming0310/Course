﻿#include "statusdialog.h"
#include "ui_statusdialog.h"

StatusDialog::StatusDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::StatusDialog)
{
    ui->setupUi(this);
    connect(ui->btn1,&QPushButton::clicked,[=](){
        status = ui->comboBox->currentIndex();
        this->close();
    });
    connect(ui->btn2,&QPushButton::clicked,[=](){
        status = -1; // 按了取消
        this->close();
    });
}

int StatusDialog::getStatusId(){
    return status;
}
StatusDialog::~StatusDialog()
{
    delete ui;
}
