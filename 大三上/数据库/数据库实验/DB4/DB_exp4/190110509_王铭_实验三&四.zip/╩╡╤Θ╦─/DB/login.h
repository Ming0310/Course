﻿#ifndef LOGIN_H
#define LOGIN_H

#include <QWidget>
#include <QStringList>
#include "global.h"
namespace Ui {
class LogIn;
}

class LogIn : public QWidget
{
    Q_OBJECT

public:
    /*
     *  用户登录界面，通过查询用户输入的账户密码是否正确决定登录是否成功
    */
    explicit LogIn(QWidget *parent = nullptr);
    ~LogIn();
signals:
    void success(User* user);// 用户登录成功
    void success(); // 管理员登陆成功

private:
    Ui::LogIn *ui;
};

#endif // LOGIN_H
