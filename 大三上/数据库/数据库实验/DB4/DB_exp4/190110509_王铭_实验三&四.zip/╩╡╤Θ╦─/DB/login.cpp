﻿#include "login.h"
#include "ui_login.h"
#include <QDebug>
#include <QMessageBox>
#include "registerdialog.h"

LogIn::LogIn(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LogIn)
{
    ui->setupUi(this);
    // 选择注册，弹出注册窗口
    connect(ui->btn_regisiter,&QPushButton::clicked,[=](){
        RegisterDialog* rd = new RegisterDialog();
        rd->show();
    });
    // 选择登录，查询用户是否存在以及输入的密码是否正确
    connect(ui->btn_login,&QPushButton::clicked,[=](){
        User* u = manager.query(ui->userName->text().toStdString());
        if(u == NULL){ // 查询用户名未存在
            QMessageBox::information(this,"register","该用户名不存在",QMessageBox::Ok);
        }
        else{ // 用户名存在，则比对密码是否正确
            if(u->getPassword() == ui->password->text().toStdString()){
                // 登录成功，则发射信号
                if(u->getType() != "2"){
                    QMessageBox::information(this,"login","登录成功",QMessageBox::Ok);
                    emit success(u);
                }
                else{
                    QMessageBox::information(this,"login","身份错误",QMessageBox::Ok);
                }
            }
            else{
                QMessageBox::information(this,"login","密码错误",QMessageBox::Ok);
            }
        }
    });
    connect(ui->pushButton,&QPushButton::clicked,[=](){
        User* u = manager.query(ui->userName->text().toStdString());
        if(u == NULL){ // 查询用户名未存在
            QMessageBox::information(this,"register","该用户名不存在",QMessageBox::Ok);
        }
        else{ // 用户名存在，则比对密码是否正确
            if(u->getPassword() == ui->password->text().toStdString()){
                // 登录成功，则发射信号
                if(u->getType() == "2"){
                     emit success();
                     QMessageBox::information(this,"login","登录成功",QMessageBox::Ok);
                }
                else{
                    QMessageBox::information(this,"login","身份错误",QMessageBox::Ok);
                }
            }
            else{
                QMessageBox::information(this,"login","密码错误",QMessageBox::Ok);
            }
        }
    });

}

LogIn::~LogIn()
{
    delete ui;
}
