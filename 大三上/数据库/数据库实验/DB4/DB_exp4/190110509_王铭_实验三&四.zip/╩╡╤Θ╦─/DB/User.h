﻿#pragma once
#include <iostream>
#include <list>
#include "orders.h"
using namespace std;
class User
{
    /*
        用户类，成员函数有账户密码，用户类型和电话号码
        该用户拥有的订单信息，用List保存
    */
private:
    string userName, password,tel;
    string user_id,student_id,type;
    string addr="";
    list<orders*> orderList;
public:
	User();
    User(string userName, string password,string user_id,string student_id = "",string tel = "",string type = "学生");
	~User();
	string getUserName();
	string getPassword();
    string getType();
    string getTel();
    string getUserId();
    string getAddr();
    void setAddr(string addr);
    void setUserId(string id);
    void setStudentId(string id);
    string getStudentId();

    list<orders*> getOrderList();
    int addToOrderList(orders* order);
    int deleteFromOrderList(string order_id);

    void setUserName(string userName);
	void setPassword(string password);
    void setTel(string tel);
    void setType(string type);

	friend ostream& operator<<(ostream& out,User user) {
        out << user.getUserName() << "," <<  user.getPassword() << "," <<  user.type << "," << user.tel;
		return out;
	}
};

