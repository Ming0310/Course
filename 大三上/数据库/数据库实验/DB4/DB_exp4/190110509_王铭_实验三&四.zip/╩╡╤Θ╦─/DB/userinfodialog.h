﻿#ifndef USERINFODIALOG_H
#define USERINFODIALOG_H

#include <QDialog>
#include "User.h"
namespace Ui {
class UserInfoDialog;
}

class UserInfoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UserInfoDialog(User* u,QWidget *parent = nullptr);
    ~UserInfoDialog();

private:
    Ui::UserInfoDialog *ui;
};

#endif // USERINFODIALOG_H
