﻿#ifndef ORDERDIALOG_H
#define ORDERDIALOG_H

#include <QDialog>
#include "User.h"

namespace Ui {
class OrderDialog;
}

class OrderDialog : public QDialog
{
    Q_OBJECT

public:
    explicit OrderDialog(User* current_user,QWidget *parent = nullptr);
    ~OrderDialog();
    void initial();

private:
    Ui::OrderDialog *ui;
};

#endif // ORDERDIALOG_H
