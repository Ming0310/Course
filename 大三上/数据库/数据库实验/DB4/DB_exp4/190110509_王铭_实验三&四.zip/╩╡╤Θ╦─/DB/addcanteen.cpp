﻿#include "addcanteen.h"
#include "ui_addcanteen.h"
#include "global.h"
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>
#include <QMessageBox>
AddCanteen::AddCanteen(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddCanteen)
{
    ui->setupUi(this);
    // 1. 获取当前最大的食堂id
    // 2. Insert一个新的食堂
    connect(ui->pushButton,&QPushButton::clicked,[=](){
        QString CName = ui->lineEdit->text();
        QString Address = ui->lineEdit_2->text();
        QString Floor = ui->lineEdit_3->text();
        Add(CName,Floor,Address);
        this->close();
    });
    connect(ui->pushButton_2,&QPushButton::clicked,[=](){
        this->close();
    });
}

int AddCanteen::Add(QString CName,QString Floor,QString Address){
    QSqlQuery q(db);
        // 1. 获取当前最大的食堂id
    int id = 0;
    q.exec("select * from canteen");
    while(q.next()){
        if(q.value("canteen_id").toInt() > id){
            id = q.value("canteen_id").toInt();
        }
    }
    bool xxx = false;
    Floor.toInt(&xxx);
    if(!xxx){
        QMessageBox::information(this,"输入错误","楼层数需为整数！",QMessageBox::Yes);
        return 0;
    }
   QSqlQuery query(db);
   query.prepare("Insert into canteen(CName,canteen_id,floorNum,canteen_addr) Values(:CName,:id,:floor,:canteen_addr)");
   query.bindValue(":CName",CName);
   query.bindValue(":id",QString::number(id+1));
   query.bindValue(":floor",Floor.toInt());
   query.bindValue(":canteen_addr",Address);
   bool flag = query.exec();
   if(!flag) qDebug() << query.lastError();
   else emit addSuccess(CName);
   return 1;
}

AddCanteen::~AddCanteen()
{
    delete ui;
}
