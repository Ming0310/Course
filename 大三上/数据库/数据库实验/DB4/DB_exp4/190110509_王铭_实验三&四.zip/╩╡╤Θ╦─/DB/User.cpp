﻿#include "User.h"
#include "global.h"
User::User() {
	this->password = "";
	this->userName = "";
}


User::User(string userName, string password,string user_id,string student_id,string tel,string type){
    this->userName = userName;
    this->password = password;
    this->user_id = user_id;
    this->student_id = student_id;
    this->tel = tel;
    this->type = type;
}

User::~User() {

}

string User::getUserName()
{
	return userName;
}

string User::getPassword()
{
	return password;
}

string User::getType(){
    return type;
}

string User::getTel(){
    return tel;
}

void User::setUserName(string userName)
{
	this->userName = userName;
}

void User::setPassword(string password)
{
	this->password = password;
}

void User::setTel(string tel){
    this->tel = tel;
}
void User::setType(string type){
    this->type = type;
}

list<orders*> User::getOrderList(){
    return orderList;
}

int User::addToOrderList(orders* order){
    orderList.push_back(order);
    return 1;
}
int User::deleteFromOrderList(string order_id){
    for(orders* order : orderList){
        if(order_id == order->getOrder_id())
        {
            orderList.remove(order);
                return 1;
        }
    }
    return 0;
}

string User::getUserId(){
    return user_id;
}

void User::setStudentId(string id){
    student_id = id;
}

string User::getStudentId(){
    return student_id;
}

void User::setUserId(string id){
    user_id = id;
}
void User::setAddr(string addr){
    this->addr = addr;
}
string User::getAddr(){
    return addr;
}
