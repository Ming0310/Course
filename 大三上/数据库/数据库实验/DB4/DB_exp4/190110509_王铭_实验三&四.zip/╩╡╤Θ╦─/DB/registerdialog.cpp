﻿#include "registerdialog.h"
#include "ui_registerdialog.h"
#include <QPushButton>
#include <QMessageBox>
#include "global.h"
#include <QDebug>
RegisterDialog::RegisterDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RegisterDialog)
{
    ui->setupUi(this);
    setWindowTitle("register");
    ui->comboBox->setCurrentIndex(0); // 默认选中身份为学生
    // 信息填写完毕，获取信息并创建一个用户
    connect(ui->register_btn,&QPushButton::clicked,[=](){
        string u = ui->user->text().toStdString();
        string p = ui->password->text().toStdString();
        string type = QString::number(ui->comboBox->currentIndex()).toStdString();
        string tel = ui->tel->text().toStdString();
        string user_id = std::to_string(manager.size);
        User* user = new User(u,p,user_id,"",tel,type);
        if(manager.query(u) == NULL){ // 返回值为空说明用户名不存在，注册成功。
            if(manager.addUser(user,true) == 1)
                QMessageBox::information(this,"register","注册成功",QMessageBox::Ok);
            else
                QMessageBox::information(this,"register","未知的错误发生了···",QMessageBox::Ok);
            this->close();
        }
        else{ // 返回值为不为空，表示该用户名已被注册。
            QMessageBox::information(this,"register","该用户名已存在",QMessageBox::Ok);
        }
    });
    connect(ui->btn1,&QPushButton::clicked,[=](){
        this->close();
    });
}

RegisterDialog::~RegisterDialog()
{
    delete ui;
}
