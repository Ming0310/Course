﻿#include "orderdialog.h"
#include "ui_orderdialog.h"
#include "global.h"
#include <QSqlQuery>
#include <QStringList>
#include <QList>
#include <QComboBox>
#include <QDebug>
#include <QSqlError>
#include "menudialog.h"
OrderDialog::OrderDialog(User* current_user,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OrderDialog)
{
    ui->setupUi(this);
    QSqlQuery query(db);
    QStringList canteenName;
    QList<int> canteenId;
    query.exec("select CName from canteen");
    while(query.next()){
        canteenName << query.value("CName").toString();
    }
    ui->canteenChoice->addItems(canteenName);
    void(QComboBox::*changed)(int) =  &QComboBox::currentIndexChanged;
    // 默认加载
    initial();
    //食堂改变，通过数据库查询，加载该食堂的所有商户信息
    connect(ui->canteenChoice,changed,[=](){
        ui->listWidget->clear();
        QSqlQuery query(db);
        query.prepare("select store_name from store,canteen where store.canteen_id = canteen.canteen_id AND CName = :CName");
        query.bindValue(":CName",ui->canteenChoice->currentText());
        if(query.exec()){
            while(query.next()){
                QListWidgetItem* item = new QListWidgetItem(query.value("store_name").toString(),ui->listWidget);
                item->setSizeHint(QSize(50,50));
            }
        }
        else{
            qDebug() << query.lastError();
        }
    });
    void(QListWidget::* c)(QListWidgetItem*) = &QListWidget::itemClicked;
    // 用户选中了该食堂的某个商户，弹出具体添加菜品的dialog，传递所需的食堂名称和商户名称
    connect(ui->listWidget,c,[=](QListWidgetItem* item){
        MenuDialog* m = new MenuDialog(ui->canteenChoice->currentText(),item->text(),current_user);
        m->show();
    });
}

void OrderDialog::initial(){
    QSqlQuery query(db);
    // 默认加载第一个食堂
    ui->canteenChoice->setCurrentIndex(0);
    query.prepare("select store_name from store,canteen where store.canteen_id = canteen.canteen_id AND CName = :CName");
    query.bindValue(":CName",ui->canteenChoice->currentText());
    if(query.exec()){
        while(query.next()){
            QListWidgetItem* item = new QListWidgetItem(query.value("store_name").toString(),ui->listWidget);
            item->setSizeHint(QSize(50,50));
        }
    }
}

OrderDialog::~OrderDialog()
{
    delete ui;
}
