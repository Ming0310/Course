﻿#include "global.h"
#include "UserManager.h"
UserManager manager = UserManager();
QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
int order_number = 0;
int max_order = 0;
