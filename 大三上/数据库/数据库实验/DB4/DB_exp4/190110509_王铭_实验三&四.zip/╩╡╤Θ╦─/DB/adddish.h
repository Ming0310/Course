﻿#ifndef ADDDISH_H
#define ADDDISH_H

#include <QWidget>

namespace Ui {
class AddDish;
}

class AddDish : public QWidget
{
    Q_OBJECT

public:
    explicit AddDish(QWidget *parent = nullptr);
    ~AddDish();
    int add(QString CName,QString store_name,QString dish_name,QString dish_price);

signals:
    void success();
private:
    Ui::AddDish *ui;
};

#endif // ADDDISH_H
