﻿#include "UserManager.h"
#include <fstream>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include "global.h"
#include <QString>
UserManager::UserManager() {

}
UserManager::~UserManager() {

}

int UserManager::addUser(User* user,bool flag)
{
	userList.push_back(user);
	if(flag == true)
		save(user);
    size++;
	return 1;
}
// delete待完善,从数据库中删除
int UserManager::deleteUser(User* user)
{
	userList.remove(user);
    size--;
	return 0;
}

User* UserManager::query(string name)
{
    QSqlQuery q(db);
    q.prepare("select * from users where user = :user");
    q.bindValue(":user",QString::fromStdString(name));
    q.exec();
    while(q.next()){
        string user = q.value("user").toString().toStdString();
        string password = q.value("password").toString().toStdString();
        string tel = q.value("telephone").toString().toStdString();
        string type = q.value("type_id").toString().toStdString();
        string student_id = q.value("student_id").toString().toStdString();
        string user_id = q.value("user_id").toString().toStdString();
        User* u = new User(user,password,user_id,student_id,tel,type);
        return u;
    }
    return NULL;
}


void UserManager::printUser()
{
	for (auto const& user : userList) {
		cout << *user << endl;
	}

}

void UserManager::initial() {
        db.setHostName("127.0.0.1");
        db.setPort(3306);
        db.setDatabaseName("test_4");
        db.setUserName("root");
        db.setPassword("100302");
        bool ok = db.open();
        if (ok){
            qDebug() << "connect database success!";
            QSqlQuery sqlQuery(db);
            sqlQuery.exec("select * from users");
            while(sqlQuery.next()){
                // 加载用户信息
                string userName = sqlQuery.value("user").toString().toStdString();
                string password = sqlQuery.value("password").toString().toStdString();
                string tel = sqlQuery.value("telephone").toString().toStdString();
                string user_id = sqlQuery.value("user_id").toString().toStdString();
                string student_id = sqlQuery.value("student_id").toString().toStdString();
                string type_id = sqlQuery.value("type_id").toString().toStdString();
                User* user = new User(userName,password,user_id,student_id,tel,type_id);
                addUser(user,false);
            }
            // 加载订单信息
            QSqlQuery query(db);
            query.exec("select * from orders");
            while(query.next()){
                string order_id = query.value("order_id").toString().toStdString();
                if(max_order < query.value("order_id").toInt()){
                    max_order = query.value("order_id").toInt();
                }
                string user_id = query.value("user_id").toString().toStdString();
                float total = query.value("total").toFloat();
                int status = query.value("status_id").toInt();
                string addr = query.value("order_addr").toString().toStdString();
                QString temp = query.value("order_time").toString();
                QStringList l = temp.split("T");
                temp = l[0]+" "+l[1].split(".")[0];
                QDateTime time = QDateTime::fromString(temp,"yyyy-MM-dd hh:mm:ss");
                orders* order = new orders(order_id,user_id,status,total,addr,time);
                addOrders(order,false);
            }
        }
        else {
            qDebug()<<"error when opening database because"<<db.lastError().text();
        }
}

int UserManager::addOrders(orders*order,bool flag){
    order_number++;
    orderList.push_back(order);
    if(flag == true){ // 加入到数据库中
        QSqlQuery query(db);
        query.prepare("insert into orders(order_id,user_id,status_id,order_time,total,order_addr) Values(:orders_id,:user_id,:status_id,:time,:total,:addr)");
        query.bindValue(":orders_id",QString::fromStdString(order->getOrder_id()));
        query.bindValue(":user_id",QString::fromStdString(order->getUser_id()));
        query.bindValue(":status_id",order->getStatus_id());
        query.bindValue(":time",order->getOrder_time());
        query.bindValue(":total",order->getTotal());
        query.bindValue(":addr",QString::fromStdString(order->getOrder_addr()));
        query.exec();
    }
    return 1;
}

void UserManager::save(User* user) {
    qDebug() << QString::fromStdString(user->getStudentId());
    QSqlQuery ins(db);
    ins.prepare("Insert into users (user,password,user_id,telephone,type_id) VALUES (:user,:password,:user_id,:tel,:type)");
    ins.bindValue(":user",QString::fromStdString(user->getUserName()));
    ins.bindValue(":password",QString::fromStdString(user->getPassword()));
    ins.bindValue(":user_id",QString::number(size));
    ins.bindValue(":tel",QString::fromStdString(user->getTel()));
    ins.bindValue(":type",QString::fromStdString(user->getType()));

    if(!ins.exec()){
        qDebug() << ins.lastError().text();
    }
}

int UserManager::deleteOrders(QString order_id){
    for(orders* order : orderList){
        if(QString::fromStdString(order->getOrder_id()) == order_id){
            orderList.remove(order);
            order_number--;
            QSqlQuery query(db);
            query.prepare("delete from orders where order_id = :id");
            query.bindValue(":id",QString::fromStdString(order->getOrder_id()));
            if(query.exec()) return 1;
            else {
                qDebug() << query.lastError();
                return 0;
            }
        }
    }
    return 0;
}

int UserManager::queryOrder(QString order_id)
{
    QSqlQuery query(db);
    query.prepare("select * from orders where order_id = :order_id");
    query.bindValue(":order_id",order_id);
    if(!query.next()){ // 若未查询到该订单 则返回0
        return 0;
    }
    // 查询到了 返回1
    else return 1;
}

list<orders*> UserManager::getOrderList(){
    return orderList;
}
