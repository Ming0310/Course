﻿#include "addstore.h"
#include "ui_addstore.h"
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>
#include "global.h"
#include <QMessageBox>
AddStore::AddStore(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddStore)
{
    ui->setupUi(this);
    connect(ui->pushButton,&QPushButton::clicked,[=](){
        int x = add(ui->lineEdit->text(),ui->lineEdit_2->text());
        if(x == 1){
            this->close();
            emit success();
        }
    });
    connect(ui->pushButton_2,&QPushButton::clicked,[=](){
        this->close();
    });
}

AddStore::~AddStore()
{
    delete ui;
}
int AddStore::add(QString canteen_name,QString store_name){
    QSqlQuery q(db);
        // 1. 获取当前最大的商户id
    int id = 0;
    q.exec("select * from store");
    while(q.next()){
        if(q.value("store_id").toInt() > id){
            id = q.value("store_id").toInt();
        }
    }
    // 2.获取食堂的id
    QSqlQuery q2(db);
    q2.prepare("select canteen_id from canteen where CName = :CName");
    q2.bindValue(":CName",canteen_name);
    q2.exec();
    if(!q2.next()){
        QMessageBox::information(this,"食堂查询错误","并未找到该食堂！",QMessageBox::Yes);
        return 0;
    }
    else{
        // 3.插入
        QSqlQuery query(db);
        qDebug() << QString::number(id+1);
        query.prepare("Insert into store(store_name,store_id,canteen_id)Values(:store_name,:id,:cid)");
        query.bindValue(":store_name",store_name);
        query.bindValue(":id",QString::number(id+1));
        query.bindValue(":cid",q2.value("canteen_id"));
        bool flag = query.exec();
        if(!flag) qDebug() << query.lastError();
    }
    return 1;
}
