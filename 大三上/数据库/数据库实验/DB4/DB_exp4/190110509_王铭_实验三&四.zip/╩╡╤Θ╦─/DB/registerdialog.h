﻿#ifndef REGISTERDIALOG_H
#define REGISTERDIALOG_H

#include <QDialog>
#include "User.h"
namespace Ui {
class RegisterDialog;
}

class RegisterDialog : public QDialog
{
    Q_OBJECT

public:
    /*
        注册窗口，实现功能：通过查询数据库中是否已经存在要注册的用户，若未存在，则注册成功，否则提示用户已经被注册了。
    */
    explicit RegisterDialog(QWidget *parent = nullptr);
    ~RegisterDialog();
    User* getUser();

private:
    Ui::RegisterDialog *ui;
};

#endif // REGISTERDIALOG_H
