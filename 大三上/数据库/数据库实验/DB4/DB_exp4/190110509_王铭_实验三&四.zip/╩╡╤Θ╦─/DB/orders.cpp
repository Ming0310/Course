﻿#include "orders.h"
#include <QSqlQuery>
#include "global.h"
#include <QString>
#include <QSqlError>
#include <QDateTime>
orders::orders()
{

}

orders::~orders()
{

}

string orders::getOrder_id(){
    return order_id;
}
string orders::getUser_id(){
    return user_id;
}
int orders::getStatus_id(){
    return status_id;
}
float orders::getTotal(){
    return total;
}
string orders::getOrder_addr(){
    return order_addr;
}
void orders::setOrder_id(string order_id){
    this->order_id = order_id;
}
void orders::setUser_id(string user_id){
    this->user_id = user_id;
}
void orders::setStatus_id(int status){
    this->status_id = status;
}
void orders::setTotal(float total){
    this->total = total;
}
void orders::setOrder_addr(string order_addr){
    this->order_addr = order_addr;
}
orders::orders(string order_id,string user_id,int status_id,float total,string order_addr,QDateTime time){
    this->order_id = order_id;
    this->user_id = user_id;
    this->status_id = status_id;
    this->total = total;
    this->order_addr = order_addr;
    this->order_time = time;
}
void orders::setOrder_time(QDateTime time){
    this->order_time = time;
}
QDateTime orders::getOrder_time(){
    return this->order_time;
}
