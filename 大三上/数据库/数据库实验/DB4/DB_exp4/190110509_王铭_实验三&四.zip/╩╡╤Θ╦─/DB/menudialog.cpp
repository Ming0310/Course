﻿#include "menudialog.h"
#include "ui_menudialog.h"
#include "global.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QListWidgetItem>
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
MenuDialog::MenuDialog(QString n,QString s,User* current_user,QWidget *parent) : // n是食堂名称，s是商户名称
    QDialog(parent),
    ui(new Ui::MenuDialog)
{
    ui->setupUi(this);
    setWindowTitle("添加菜品");
    QSqlQuery query(db); // 查询当前所选的食堂的商户提供的菜品，打印到ListWidget上
    query.prepare("select dish_name,dish_price from store,dish,canteen where store.store_id = dish.store_id "
                  "AND store.canteen_id = canteen.canteen_id AND CName = :CName AND store_name = :SName");
    query.bindValue(":CName",n);
    query.bindValue(":SName",s);
    if(query.exec()){
        while(query.next()){
            QListWidgetItem* item = new QListWidgetItem(query.value("dish_name").toString() + "\t价格：" + query.value("dish_price").toString()+"元",ui->listWidget);
            item->setSizeHint(QSize(50,50));
        }
    }
    else{
        qDebug() << query.lastError();
    }
    order = new orders();
    QDateTime time = QDateTime::currentDateTime();
    order->setOrder_time(time);
    order->setUser_id(current_user->getUserId());
    order->setOrder_id(std::to_string(++max_order));
    order->setTotal(0);
    order->setStatus_id(0);
    order->setOrder_addr(current_user->getAddr());
    void(QListWidget::* c)(QListWidgetItem*) = &QListWidget::itemClicked;
    // 选择一个菜品，触发信号，添加菜品成功。
    // 添加菜品
    connect(ui->listWidget,c,[=](QListWidgetItem* item){
        int flag = manager.queryOrder(QString::fromStdString(order->getOrder_id()));
        if(!flag){
            current_user->addToOrderList(order);
            manager.addOrders(order);
        }
        QString dish_name = item->text().split("\t")[0];
        string dish_id = getDishId(n.toStdString(),dish_name.toStdString());
        float price = getDishPrice(dish_id);
        QSqlQuery query(db);
        query.prepare("select * from orders_dish where order_id = :order_id and dish_id = :dish_id");
        query.bindValue(":order_id",QString::fromStdString(order->getOrder_id()));
        query.bindValue(":dish_id",QString::fromStdString(dish_id));
        query.exec();
        if(!query.next()){ // 未查询到,添加
            QSqlQuery query(db);
            query.prepare("insert into orders_dish(order_id,dish_id,number) Values(:order_id,:dish_id,1)");
            query.bindValue(":order_id",QString::fromStdString(order->getOrder_id()));
            query.bindValue(":dish_id",QString::fromStdString(dish_id));
            bool flag = query.exec();
            if(!flag) qDebug() << "添加失败" << " " << query.lastError();
        }
        else{ // 更新数量加1
            QSqlQuery query(db);
            query.prepare("update orders_dish set number = number + 1 where order_id = :order_id AND dish_id = :dish_id");
            query.bindValue(":order_id",QString::fromStdString(order->getOrder_id()));
            query.bindValue(":dish_id",QString::fromStdString(dish_id));
            query.exec();
        }
        // 写回数据库
        updateOrder(order->getOrder_id(),price);
        // 更新current_user
        current_user->deleteFromOrderList(order->getOrder_id());
        current_user->addToOrderList(order);
        QMessageBox::information(this,"成功","添加成功",QMessageBox::Ok);
    });


}
string MenuDialog::getDishId(string canteen_name,string dish_name){
    QSqlQuery query(db);
     query.prepare("select * from dish,canteen,store where store.store_id = dish.store_id and canteen.canteen_id = store.canteen_id and canteen.CName = :CName and dish.dish_name = :DName");
     query.bindValue(":CName",QString::fromStdString(canteen_name));
     query.bindValue(":DName",QString::fromStdString(dish_name));
    if(query.exec()){
        query.next();
        return query.value("dish_id").toString().toStdString();
    }
    else{
        qDebug() << query.lastError();
        return NULL;
    }
}
float MenuDialog::getDishPrice(string dish_id){
    QSqlQuery query(db);
     query.prepare("select * from dish where dish_id = :dish_id");
     query.bindValue(":dish_id",QString::fromStdString(dish_id));
    if(query.exec()){
        query.next();
        return query.value("dish_price").toFloat();
    }
    else{
        qDebug() << query.lastError();
        return 0;
    }
}
int MenuDialog::updateOrder(string order_id, float price){
    // 更新manager的orderList
    for(orders* order : manager.orderList){
        if(order->getOrder_id() == order_id){
            manager.orderList.remove(order);
            order->setOrder_time(QDateTime::currentDateTime());
            order->setTotal(order->getTotal() + price);
            manager.orderList.push_back(order);
            break;
        }
    }
    // 更新数据库里的orderList
    QSqlQuery q(db);
    q.prepare("update orders set order_time = :time,total = total + :price where order_id = :order_id");
    q.bindValue(":time",QDateTime::currentDateTime());
    q.bindValue(":order_id",QString::fromStdString(order_id));
    q.bindValue(":price",price);
    q.exec();
    // 更新成功返回1
    return 1;
}
MenuDialog::~MenuDialog()
{
    delete ui;
}
