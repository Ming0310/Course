﻿#include "mainwindow.h"
#include "login.h"
#include "global.h"
#include <QApplication>
#include <QObject>
#include <QDebug>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlError>
#include "rootmainwindow.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);    
    manager.initial();
    LogIn* login = new LogIn();
    void(LogIn::*func1)(User*) = &LogIn::success;
    void(LogIn::*func2)() = &LogIn::success;
    QObject::connect(login,func1,[=](User* user){
        login->hide();
        MainWindow* w = new MainWindow(user);
        w->show();
        QObject::connect(w,&MainWindow::reshow,[=](){
           login->show();
        });
    });
    QObject::connect(login,func2,[=](){
        login->hide();
        RootMainWindow* w = new RootMainWindow();
        w->show();
        QObject::connect(w,&RootMainWindow::reshow,[=](){
           login->show();
        });
    });
    login->show();
    return a.exec();
}
