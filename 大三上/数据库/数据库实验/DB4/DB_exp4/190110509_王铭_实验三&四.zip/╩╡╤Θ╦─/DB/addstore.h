﻿#ifndef ADDSTORE_H
#define ADDSTORE_H

#include <QWidget>

namespace Ui {
class AddStore;
}

class AddStore : public QWidget
{
    Q_OBJECT

public:
    explicit AddStore(QWidget *parent = nullptr);
    ~AddStore();
    int add(QString canteen_name,QString store_name);
signals:
    void success();
private:
    Ui::AddStore *ui;
};

#endif // ADDSTORE_H
