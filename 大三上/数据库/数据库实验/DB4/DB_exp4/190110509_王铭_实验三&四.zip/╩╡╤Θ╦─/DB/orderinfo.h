﻿#ifndef ORDERINFO_H
#define ORDERINFO_H

#include <QWidget>

namespace Ui {
class OrderInfo;
}

class OrderInfo : public QWidget
{
    Q_OBJECT

public:
    explicit OrderInfo(QString id,QWidget *parent = nullptr);
    ~OrderInfo();

private:
    Ui::OrderInfo *ui;
};

#endif // ORDERINFO_H
