﻿#ifndef GLOBAL_H
#define GLOBAL_H
#include "UserManager.h"
#include <QSqlDatabase>
extern UserManager manager;
extern QSqlDatabase db;
extern int order_number;
extern int max_order;
#endif // GLOBAL_H
